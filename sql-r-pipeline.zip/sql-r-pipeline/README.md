# SQL + R Analysis Pipeline (Chinook Music Store)

**Question:** *(fill in)* Who are the highest-value customers, which genres drive the most revenue, and how is revenue trending?

**Key findings:** *(fill in after running; 2-3 bullets with numbers)*

**Tools:** SQL (SQLite), DBI, dbplyr, R, tidyverse, Quarto

## Why this project

Most beginner R portfolios only ever read a CSV. Real analyst work usually starts in a database. This project shows the pipeline an analyst actually uses day to day: write SQL to aggregate inside the database, pull only the small summarized result into R, then visualize and interpret it.

## Reproduce

1. Download the Chinook SQLite database (see `R/00_get_data.R` for the link) and save it as `data/db/chinook.db`
2. `install.packages(c("DBI", "RSQLite", "dbplyr", "dplyr", "tidyverse", "scales", "quarto"))`
3. Run `R/01_run_queries.R` to execute the SQL files and save the results
4. Optionally run `R/02_dplyr_vs_sql.R` to see the same query written in dplyr
5. Render `reports/report.qmd`

## SQL concepts demonstrated

| File | Concept |
|---|---|
| `sql/01_explore_schema.sql` | Listing tables, inspecting structure |
| `sql/02_top_customers.sql` | Multi-table JOIN, GROUP BY, aggregation |
| `sql/03_revenue_by_genre.sql` | Multi-hop JOIN (3 tables) |
| `sql/04_monthly_revenue_with_window.sql` | CTE, window functions (running total, LAG) |
| `sql/05_customer_lifetime_value_cte.sql` | CTE + CASE WHEN for segmentation |

## Project structure

```
R/00_get_data.R              where to get the data
R/db_connect.R                database connection helper
sql/*.sql                     analysis queries
R/01_run_queries.R            runs the SQL files, saves results
R/02_dplyr_vs_sql.R           same query in dplyr/dbplyr for comparison
reports/report.qmd            written analysis and charts
```

## Limitations

*(fill in)*
