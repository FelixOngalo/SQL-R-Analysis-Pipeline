-- Monthly revenue plus a running total and month-over-month change,
-- using window functions (OVER / LAG) rather than a self-join.
WITH monthly AS (
  SELECT
    strftime('%Y-%m', i.invoice_date) AS month,
    ROUND(SUM(i.total), 2)            AS revenue
  FROM invoices i
  GROUP BY month
)
SELECT
  month,
  revenue,
  ROUND(SUM(revenue) OVER (ORDER BY month), 2)              AS running_total,
  ROUND(revenue - LAG(revenue) OVER (ORDER BY month), 2)    AS change_vs_prior_month
FROM monthly
ORDER BY month;
