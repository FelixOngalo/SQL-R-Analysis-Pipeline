-- Revenue by genre: JOIN invoice line items -> tracks -> genres,
-- an example of a multi-hop join analysts write constantly.
SELECT
  g.name                                      AS genre,
  ROUND(SUM(ii.unit_price * ii.quantity), 2)  AS revenue,
  COUNT(DISTINCT ii.invoice_id)               AS orders
FROM invoice_items ii
JOIN tracks  t ON t.track_id = ii.track_id
JOIN genres  g ON g.genre_id = t.genre_id
GROUP BY g.name
ORDER BY revenue DESC;
