-- List every table in the database
SELECT name FROM sqlite_master WHERE type = 'table';

-- Look at one table's structure
PRAGMA table_info(invoices);
