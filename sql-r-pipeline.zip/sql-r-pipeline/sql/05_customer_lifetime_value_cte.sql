-- Customer lifetime value using a CTE, then a second pass to bucket
-- customers into value tiers. CTEs (WITH ...) make multi-step SQL
-- readable instead of nesting subqueries.
WITH customer_totals AS (
  SELECT
    c.customer_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    ROUND(SUM(ii.unit_price * ii.quantity), 2) AS lifetime_value
  FROM customers c
  JOIN invoices i       ON i.customer_id = c.customer_id
  JOIN invoice_items ii ON ii.invoice_id = i.invoice_id
  GROUP BY c.customer_id, customer_name
)
SELECT
  customer_name,
  lifetime_value,
  CASE
    WHEN lifetime_value >= 40 THEN 'High value'
    WHEN lifetime_value >= 20 THEN 'Mid value'
    ELSE 'Low value'
  END AS value_tier
FROM customer_totals
ORDER BY lifetime_value DESC;
