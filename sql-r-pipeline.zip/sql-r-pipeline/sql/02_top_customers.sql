-- Top 10 customers by total spend, with country for context.
-- JOIN across customers -> invoices -> invoice line items.
SELECT
  c.customer_id,
  c.first_name || ' ' || c.last_name AS customer_name,
  c.country,
  ROUND(SUM(ii.unit_price * ii.quantity), 2) AS total_spent,
  COUNT(DISTINCT i.invoice_id)               AS num_orders
FROM customers c
JOIN invoices i          ON i.customer_id = c.customer_id
JOIN invoice_items ii    ON ii.invoice_id = i.invoice_id
GROUP BY c.customer_id, customer_name, c.country
ORDER BY total_spent DESC
LIMIT 10;
