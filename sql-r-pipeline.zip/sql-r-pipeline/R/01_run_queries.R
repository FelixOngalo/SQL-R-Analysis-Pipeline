# Run each .sql file from the sql/ folder and pull the result into R.
# This is the core pattern of a SQL+R pipeline: SQL does the heavy
# aggregation inside the database; R takes the (small) result and
# visualizes or models it.

library(DBI)
source("R/db_connect.R")

run_sql_file <- function(con, path) {
  query <- paste(readLines(path), collapse = "\n")
  dbGetQuery(con, query)
}

con <- get_con()

top_customers   <- run_sql_file(con, "sql/02_top_customers.sql")
revenue_genre   <- run_sql_file(con, "sql/03_revenue_by_genre.sql")
monthly_revenue <- run_sql_file(con, "sql/04_monthly_revenue_with_window.sql")
clv             <- run_sql_file(con, "sql/05_customer_lifetime_value_cte.sql")

dbDisconnect(con)

dir.create("data/db", showWarnings = FALSE)
saveRDS(list(top_customers = top_customers, revenue_genre = revenue_genre,
             monthly_revenue = monthly_revenue, clv = clv),
        "data/db/query_results.rds")

message("Saved query results to data/db/query_results.rds")
