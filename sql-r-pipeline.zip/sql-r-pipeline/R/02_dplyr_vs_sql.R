# The same top-10-customers query, written with dbplyr instead of raw SQL.
# dbplyr translates dplyr verbs into SQL and runs them IN the database,
# so this stays fast even on a large table -- only the final small
# result is pulled into R with collect().

library(DBI)
library(dplyr)
library(dbplyr)
source("R/db_connect.R")

con <- get_con()

customers      <- tbl(con, "customers")
invoices       <- tbl(con, "invoices")
invoice_items  <- tbl(con, "invoice_items")

top_customers_dplyr <- customers |>
  inner_join(invoices, by = "customer_id") |>
  inner_join(invoice_items, by = "invoice_id") |>
  group_by(customer_id, first_name, last_name, country) |>
  summarise(total_spent = sum(unit_price * quantity, na.rm = TRUE), .groups = "drop") |>
  arrange(desc(total_spent)) |>
  head(10)

# See the SQL dbplyr actually generates:
show_query(top_customers_dplyr)

# Only now does anything leave the database:
result <- collect(top_customers_dplyr)
print(result)

dbDisconnect(con)
