# Data for this project: Chinook, a sample digital music store database
# (customers, invoices, invoice line items, tracks, artists — a classic
# relational schema analysts run into constantly).
#
# Download the SQLite version:
#   https://github.com/lerocha/chinook-database
#   -> ChinookDatabase (SQLite) release, e.g. "Chinook_Sqlite.sqlite"
# Place the file at data/db/chinook.db (rename if needed).
#
# Why SQLite: no server to install, and DBI/RSQLite connect to it exactly
# like any production database, so the R code you write here transfers
# directly to Postgres/MySQL with only the connection line changed.

message("Download the Chinook SQLite database and save it as data/db/chinook.db")
message("See comments in this file for the source link.")
