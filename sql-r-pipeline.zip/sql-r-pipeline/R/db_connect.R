# Central place to open/close the database connection.
# Swapping RSQLite for RPostgres later only requires changing this file.

library(DBI)
library(RSQLite)

get_con <- function(path = "data/db/chinook.db") {
  dbConnect(RSQLite::SQLite(), path)
}
